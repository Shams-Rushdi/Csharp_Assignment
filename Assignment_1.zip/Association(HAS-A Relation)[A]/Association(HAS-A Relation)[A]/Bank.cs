﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Association_HAS_A_Relation__A_;

namespace Association_HAS_A_Relation__A_
{
    class Bank
    {
        private string bankName;
        private Account[] myBank;//1-* Relation
        public Bank(string name, int size)
        {
            this.bankName = name;
            myBank = new Account[size];
        }
        public string Name
        {
            set { this.bankName = value; }
            get { return this.bankName; }
        }
        public Account[] Accounts
        {
            set { this.myBank = value; }
            get { return this.myBank; }
        }

        public void PrintAllAccounts()
        {
            for (int i = 0; i < myBank.Length; i++)
            {
                if (myBank[i] == null)
                {
                    continue;
                }
                myBank[i].PrintAccount();
            }
        }
        public void AddAccount(Account account)
        {
            for (int i = 0; i < myBank.Length; i++)
            {
                if (myBank[i] == null)
                {
                    myBank[i] = account;
                    break;
                }
            }
        }


        public void PrintAddAccount()
        {


        }




        public void DeleteAccount(int accountNo)
        {
            int flag = 0;
            for (int i = 0; i < myBank.Length; i++)
            {
                if (myBank[i] == null)
                {
                    continue;
                }
                else if (myBank[i].AccountNumber == accountNo)
                {
                    //accounts[i].PrintAccount();
                    flag = 0;
                    for( int j=i; j<(myBank.Length-1); j++)
                    {
                        if(j< myBank.Length-1)
                        {
                            myBank[j] = null;
                            myBank[j] = myBank[j+1];
                            
                        }
                        else
                        {
                            myBank[j] = null;
                        }
                    }
                    Console.WriteLine("This account has been deleted");
                    Console.WriteLine("..............................");
                    //Console.WriteLine("New List......................");
                    break;
                }
                else
                {
                    flag = 1;

                }
            }
            if (flag == 1)
                Console.WriteLine("Account Not Found");
        }



        public void Transaction(int accountNo,double amount)
        {
            //Bank ourBank = new Bank("Developer's bank", 5);
            int flag = 0;
            for (int i = 0; i < myBank.Length; i++)
               {
                  if (myBank[i] == null)
                    {
                        continue;
                    }
                    else if (myBank[i].AccountNumber == accountNo)
                    {
                        myBank[i].Withdraw(amount);
                        flag = 0;
                        break;
                    }
                    else
                    {
                        flag = 1;

                    }
                }
                if (flag == 1)
                    Console.WriteLine("Account Not Found");
           
        }


        public void Transaction2(int accountNo, double amount)
        {
            //Bank ourBank = new Bank("Developer's bank", 5);
            int flag = 0;
            for (int i = 0; i < myBank.Length; i++)
            {
                if (myBank[i] == null)
                {
                    continue;
                }
                else if (myBank[i].AccountNumber == accountNo)
                {
                    myBank[i].Deposite(amount);
                    flag = 0;
                    break;
                }
                else
                {
                    flag = 1;

                }
            }
            if (flag == 1)
                Console.WriteLine("Account Not Found");

        }


        //public bool withdraw(double amount)
        //{
        //    if (amount > 0 && amount <= balance)
        //    {
        //        balance = balance - amount;
        //        return true;
        //    }
        //    else if (amount > balance)
        //    {
        //        // error reporting code omitted
        //        return false;
        //    }
        //    else
        //    {
        //        // error reporting code omitted
        //        return false;
        //    }
        //}


        //public void SearchAccount(int accountNo)
        //{
        //    int flag = 0;
        //    for (int i = 0; i < accounts.Length; i++)
        //    {
        //        if (accounts[i] == null)
        //        {
        //            continue;
        //        }
        //        else if (accounts[i].AccountNumber == accountNo)
        //        {
        //            accounts[i].PrintAccount();
        //            flag = 0;
        //            break;
        //        }
        //        else
        //        {
        //            flag = 1;

        //        }
        //    }
        //    if (flag == 1)
        //        Console.WriteLine("Account Not Found");
        //}










    }
}
