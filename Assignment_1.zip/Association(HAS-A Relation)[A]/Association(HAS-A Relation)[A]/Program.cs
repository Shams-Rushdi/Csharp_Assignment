﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Association_HAS_A_Relation__A_;


namespace Association_HAS_A_Relation__A_
{
    class Program
    {

        static void Main(string[] args)
        {


            Bank ourBank = new Bank("Sonaly bank", 10);
            ourBank.AddAccount(new Account(1001, "Shakib", 2000, new Address("4", "10", "Dhaka", "Bangladesh")));
            ourBank.AddAccount(new Account(1002, "Mushfiq", 5000, new Address("5", "15", "Chicago", "USA")));
            ourBank.AddAccount(new Account(1003, "Tamim", 3000, new Address("10", "20", "Cold Lake", "Canada")));


            Console.WriteLine("0. Print All Account  ");
            Console.WriteLine("1. AddAccount ");
            Console.WriteLine("2. DeleteAccount ");
            Console.WriteLine("3. Transaction ");
            Console.WriteLine("      ");
            Console.WriteLine("Enter the operation: ");
            int num = System.Convert.ToInt32(Console.ReadLine());

            if (num == 0)                            //All Account
            {
                Console.WriteLine("      ");
                ourBank.PrintAllAccounts();
                
            }

            else if (num == 1)                  //AddAccount
            {

                Console.WriteLine("      ");
                Console.WriteLine("Account Number: ");
                int acnumber = System.Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Account Holdername: ");
                string name = Console.ReadLine();
                int balance = 0;
                Console.WriteLine("House No: ");
                string houNo = Console.ReadLine();
                Console.WriteLine("Road No:  ");
                string rodNo = Console.ReadLine();
                Console.WriteLine("City Name: ");
                string CitNam = Console.ReadLine();
                Console.WriteLine("Country Name: ");
                string CounNam = Console.ReadLine();
                ourBank.AddAccount(new Account(acnumber, name, balance, new Address(houNo, rodNo, CitNam, CounNam)));
                Console.WriteLine("      ");
                Console.WriteLine("Your Account has been created ");
                Console.WriteLine("      ");
                //ourBank.PrintAddAccount(new Account);
                Console.WriteLine("---------------------------------------");
                ourBank.PrintAllAccounts();


            }
            else if (num == 2)                      //  DeleteAccount
            {
                Console.WriteLine("      ");
                Console.WriteLine("Enter Account Number");
                int acnumber = System.Convert.ToInt32(Console.ReadLine());
                ourBank.DeleteAccount(acnumber);
                Console.WriteLine("---------------------------------------");
                ourBank.PrintAllAccounts();
                

            }
            else                                     // Transaction
             {

                
                Console.WriteLine("1. Withdraw ");
                Console.WriteLine("2. Deposit ");
                Console.WriteLine("3. Transfer ");
                Console.WriteLine("      ");
                Console.WriteLine(" Which Type Of Transaction do you want: ");
                int tra = System.Convert.ToInt32(Console.ReadLine());
               

                if (tra == 1)                           // Withdraw
                    {
                        Console.WriteLine("Account Number: ");
                        int acnumber = System.Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("amount : ");
                        double taka = System.Convert.ToDouble(Console.ReadLine());
                        ourBank.Transaction(acnumber, taka);
                        Console.WriteLine("---------------------------------------");
                        ourBank.PrintAllAccounts();
                    }


                else if (tra == 2)                       //Deposit
                    {
                        Console.WriteLine("      ");
                        Console.WriteLine("Please give your Account number:");
                        int acnumber = System.Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Please give your deposite amount:");
                        double taka = System.Convert.ToDouble(Console.ReadLine());
                        ourBank.Transaction2(acnumber, taka);
                        Console.WriteLine("---------------------------------------");
                        ourBank.PrintAllAccounts();
                    }



                else                                     //Transfer
                    {
                        Console.WriteLine("From: ");
                        Console.WriteLine("Please give sender Account number:");
                        int acnumber = System.Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Please give the amount:");
                        double taka = System.Convert.ToDouble(Console.ReadLine());
                        ourBank.Transaction(acnumber, taka);

                        Console.WriteLine("To: ");
                        Console.WriteLine("Please give receiver Account number:");
                        int acnumber2 = System.Convert.ToInt32(Console.ReadLine());
                        ourBank.Transaction2(acnumber2, taka);
                        Console.WriteLine("transferred");
                        Console.WriteLine("---------------------------------------");
                        ourBank.PrintAllAccounts();
                    }


            }
        }
    }
}
