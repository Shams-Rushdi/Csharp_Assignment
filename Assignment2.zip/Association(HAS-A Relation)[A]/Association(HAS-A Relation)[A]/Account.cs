﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Association_HAS_A_Relation__A_;


namespace Association_HAS_A_Relation__A_
{
    //enum AccountType : byte
    //{
    //    Saving,
    //    Checking
    //}

    class Account
    {
        //private int accountNumber= new Random().Next(1000, 2000);
        private int accountNumber;
        private string accountName;
        private double balance;
        private Address address;
        private string dateofBirth ;
        private string accountType; //1-1 Relation



        public Account(int accountNumber, string accountName, string accountType, string dateofBirth, double balance, Address address)     //int accountNumber,
        {
            this.accountNumber = accountNumber;
            this.accountName = accountName;
            this.accountType = accountType;
            this.balance = balance;
            this.address = address;
            this.dateofBirth= dateofBirth;
            
        }


        public int AccountNumber
        {

            set { this.accountNumber = value; }
            get
            {
                return this.accountNumber;

            }
        }
        //public void AccountNumber()
        //{
        //    int num = 1;
        //    int id = 2000;
        //    for (int  i = 0; i < num ;i++)
        //    {
        //        Console.WriteLine(id++);
        //        //this.accountNumber = id++;
        //    }
        //}



        public string AccountName
        {
            get { return this.accountName; }
            set { this.accountName = value; }
        }
        public double Balance
        {
            get { return this.balance; }
            set { this.balance = value; }
        }
        public string DateofBirth
        {
            get { return this.dateofBirth; }
            set { this.dateofBirth = value; }
        }

        public Address Address
        {
            get { return this.address; }
            set { this.address = value; }
        }


        public string AccountType
        {
            get { return this.accountType; }
            set { this.accountType = value; }
        }



        public void CheckingWithdraw(double amount)             //Checking Acount  can be zero
        {   
            if (this.Balance >= amount)
            {
                this.balance = this.balance - amount;
                Console.WriteLine("Withdraw successful");
                
            }
            else
            {
                Console.WriteLine("Insufficient balance");
            }
            //return this.balance;
            
        }

        public void SavingWithdraw(double amount)             //saving Account can not be zero
        {
            if (this.Balance > amount)
            {
                this.balance = this.balance - amount;
                Console.WriteLine("Withdraw successful");

            }
            else
            {
                Console.WriteLine("Insufficient balance");
            }
            //return this.balance;

        }




        public void Withdraw(double amount)
        {
            //string accouuntType = null;

            if ( this.AccountType == "saving"  &&   this.Balance > amount)
            {
                this.balance = this.balance - amount;
                Console.WriteLine("Withdraw successful");

            }
            else if(this.AccountType == "checking" && this.Balance >= amount)
            {
                this.balance = this.balance - amount;
                Console.WriteLine("Withdraw successful");
            }
            else
            {
                Console.WriteLine("Insufficient balance");
            }
            //return this.balance;

        }








        public void Deposite(double amount)
        {
            if (this.Balance > amount)
            {
                this.balance = this.balance + amount;
                Console.WriteLine("Deposite successful");
            }
            else
            {
                Console.WriteLine("Negetive number cannot insert");
                
            }
            //return this.balance;

        }


        public void PrintAccount()
        {
            //Console.WriteLine("Account No:"+this.accountNumber+"\nAccount Name:"+this.accountName+"\nBalance:"+this.balance);
            Console.WriteLine("Account No:{0}\nAccount Name:{1}\nAccount Type:{2}\nDate of Birth:{3}\nBalance:{4}", this.accountNumber, this.accountName,this.accountType, this.dateofBirth, this.balance );
            this.address.PrintAddress();
        }


    }
}







//int flag = 0;
//for (int i = 0; i < _id.Length; i++)
//{
//    if (myBank[i] == null)
//    {
//        continue;
//    }
//    else if (myBank[i].AccountNumber == accountNo)
//    {
//        //accounts[i].PrintAccount();
//        flag = 0;
//        for (int j = i; j < (myBank.Length - 1); j++)
//        {
//            if (j < myBank.Length - 1)
//            {
//                myBank[j] = null;
//                myBank[j] = myBank[j + 1];

//            }
//            else
//            {
//                myBank[j] = null;
//            }
//        }
//        Console.WriteLine("This account has been deleted");
//        Console.WriteLine("..............................");
//        //Console.WriteLine("New List......................");
//        break;
//    }
//    else
//    {
//        flag = 1;

//    }
//}
//if (flag == 1)
//    Console.WriteLine("Account Not Found");

