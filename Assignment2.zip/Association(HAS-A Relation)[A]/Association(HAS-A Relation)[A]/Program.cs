﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Association_HAS_A_Relation__A_;


namespace Association_HAS_A_Relation__A_
{
 class Program
    {
        
        static void Main(string[] args)
        {
            
            
            Bank ourBank = new Bank("Developers Bank", 10);
            ourBank.AddAccount(new Account(1001, "Shakib", "saving",  "20-3-1991", 2000, new Address("4", "10", "Dhaka", "Bangladesh")));
            ourBank.AddAccount(new Account(1002, "Mushfiq", "checking", "14-8-1985", 5000, new Address("5", "15", "Chicago", "USA")));
            ourBank.AddAccount(new Account(1003, "Tamim", "saving", "8-12-1990", 3000, new Address("10", "20", "Cold Lake", "Canada")));

            //string str;
            



                Console.WriteLine("  ");
                Console.WriteLine("***********Developers Bank***********");
                Console.WriteLine("  ");
                Console.WriteLine("Open a Bank account  ");
                Console.WriteLine("Perfrom transactions for an account ");
                Console.WriteLine("Exiit the application ");
                Console.WriteLine("");
                Console.WriteLine("Choose an Operation:(Open / Account) ");

                string str = Console.ReadLine();
                Console.WriteLine("");

                int id = 1003;
                for (int i = 0; i < 1; i++)                     // Automatic Id Generate
                {
                    id++;
                }

                //string str = Console.ReadLine();
                //Console.WriteLine("");


                switch (str)
                {
                    case "open":


                        Console.WriteLine("Choose an Operation:(Saving/ Checking) ");
                        string input = Console.ReadLine();

                        switch (input)
                        {
                            case "saving":
                                Console.WriteLine("      ");
                                string acctype = "saving";
                                Console.WriteLine("Account Holdername: ");
                                string name = Console.ReadLine();
                                Console.WriteLine("Date Of Birth: ");
                                string dateofbirth = Console.ReadLine();
                                Console.WriteLine("Enter your ammount: ");
                                int balance = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("House No: ");
                                string houNo = Console.ReadLine();
                                Console.WriteLine("Road No:  ");
                                string rodNo = Console.ReadLine();
                                Console.WriteLine("City Name: ");
                                string CitNam = Console.ReadLine();
                                Console.WriteLine("Country Name: ");
                                string CounNam = Console.ReadLine();
                                //ourBank.AddAccount(new Account(acnumber, name, balance, new Address(houNo, rodNo, CitNam, CounNam)));
                                ourBank.AddAccount(new Account(id, acctype, name,dateofbirth, balance, new Address(houNo, rodNo, CitNam, CounNam)));
                                Console.WriteLine("Your Saving Account has been created ");
                                Console.WriteLine("      ");
                                //ourBank.PrintAddAccount(new Account);
                                Console.WriteLine("---------------------------------------");
                                ourBank.PrintAllAccounts();

                                break;


                            case "checking":
                                Console.WriteLine("      ");
                                string acctype4 = "checking";
                                Console.WriteLine("Account Holdername: ");
                                string name2 = Console.ReadLine();
                                string dateofbirth2 = Console.ReadLine();
                                Console.WriteLine("Enter your ammount: ");
                                Console.WriteLine("Enter your ammount: ");
                                int balance2 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("House No: ");
                                string houNo2 = Console.ReadLine();
                                Console.WriteLine("Road No:  ");
                                string rodNo2 = Console.ReadLine();
                                Console.WriteLine("City Name: ");
                                string CitNam2 = Console.ReadLine();
                                Console.WriteLine("Country Name: ");
                                string CounNam2 = Console.ReadLine();
                                //ourBank.AddAccount(new Account(acnumber, name, balance, new Address(houNo, rodNo, CitNam, CounNam)));
                                ourBank.AddAccount(new Account(id, acctype4, name2, dateofbirth2, balance2, new Address(houNo2, rodNo2, CitNam2, CounNam2)));
                                Console.WriteLine("Your Checking Account has been created ");
                                Console.WriteLine("      ");
                                //ourBank.PrintAddAccount(new Account);
                                Console.WriteLine("---------------------------------------");
                                ourBank.PrintAllAccounts();

                                break;

                            case "quit":
                                
                                break;
                            default:
                                Console.WriteLine("Wrong Keyword");
                                break;
                        }

                        break;


                    case "account":
                        Console.WriteLine("Choose an Operation:(Deposit / Withdraw / Transfer / Show ) ");

                        string input2 = Console.ReadLine();

                        switch (input2)
                        {
                            case "deposit":
                                Console.WriteLine("      ");
                                Console.WriteLine("Please give your Account number:");
                                int acnumber = System.Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Please give your deposite amount:");
                                double taka = System.Convert.ToDouble(Console.ReadLine());
                                ourBank.Transaction2(acnumber, taka);
                                Console.WriteLine("---------------------------------------");
                                ourBank.PrintAllAccounts();
                                break;
                            case "withdraw":
                                Console.WriteLine("Account Number: ");
                                int acnumber2 = System.Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("amount : ");
                                double taka2 = System.Convert.ToDouble(Console.ReadLine());
                                ourBank.Transaction(acnumber2, taka2);
                                Console.WriteLine("---------------------------------------");
                                ourBank.PrintAllAccounts();
                                break;
                            case "transfer":
                                Console.WriteLine("From: ");
                                Console.WriteLine("Please give sender Account number:");
                                int acnumber3 = System.Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Please give the amount:");
                                double taka3 = System.Convert.ToDouble(Console.ReadLine());
                                ourBank.Transaction(acnumber3, taka3);

                                Console.WriteLine("To: ");
                                Console.WriteLine("Please give receiver Account number:");
                                int acnumber4 = System.Convert.ToInt32(Console.ReadLine());
                                ourBank.Transaction2(acnumber4, taka3);
                                Console.WriteLine("transferred");
                                Console.WriteLine("---------------------------------------");
                                ourBank.PrintAllAccounts();
                                break;
                            case "show":
                                Console.WriteLine("Thursday");
                                break;
                            case "quit":
                                //choice = choice.ToUpper();
                                
                                break;
                            default:
                                Console.WriteLine("Wrong Keyword");
                                break;

                        }


                        break;
                    default:
                        Console.WriteLine("Wrong Keyword");
                        break;

                } 


            }





































            //        Console.WriteLine("0. Print All Account  ");
            //        Console.WriteLine("1. AddAccount ");
            //        Console.WriteLine("2. DeleteAccount ");
            //        Console.WriteLine("3. Transaction ");
            //        Console.WriteLine("      ");
            //        Console.WriteLine("Enter the operation: ");
            //        int num = System.Convert.ToInt32(Console.ReadLine());

            //        if (num == 0)                            //All Account
            //        {
            //            Console.WriteLine("      ");
            //            ourBank.PrintAllAccounts();

            //        }

            //        else if (num == 1)                  //AddAccount
            //        {

            //    //Console.WriteLine("How many account do you create ");

            //            //int id = 1004;
            //            //for (int i = 0; i < num2; i++)                     // Automatic Id Generate
            //            //{

            //            //    Console.WriteLine("      ");
            //            //    Console.WriteLine("Account Holdername: ");
            //            //    string name = Console.ReadLine();
            //            //    int balance = 0;
            //            //    Console.WriteLine("House No: ");
            //            //    string houNo = Console.ReadLine();
            //            //    Console.WriteLine("Road No:  ");
            //            //    string rodNo = Console.ReadLine();
            //            //    Console.WriteLine("City Name: ");
            //            //    string CitNam = Console.ReadLine();
            //            //    Console.WriteLine("Country Name: ");
            //            //    string CounNam = Console.ReadLine();
            //            //    //ourBank.AddAccount(new Account(acnumber, name, balance, new Address(houNo, rodNo, CitNam, CounNam)));
            //            //    ourBank.AddAccount(new Account(id, name, balance, new Address(houNo, rodNo, CitNam, CounNam)));
            //            //    Console.WriteLine("Your Account has been created ");
            //            //    Console.WriteLine("      ");
            //            //    //ourBank.PrintAddAccount(new Account);
            //            //    Console.WriteLine("---------------------------------------");
            //                //ourBank.PrintAllAccounts();




            //                //Console.WriteLine("20-" + id++ + "-1");
            //                //ourBank.AddAccount(new Account(id, "Tamim", 3000, new Address(7, 20, "Chittagong")));
            //                //Console.WriteLine();
            //            }

            //            ourBank.PrintAllAccounts();



            //}
            //else if (num == 2)                      //  DeleteAccount
            //        {
            //            Console.WriteLine("      ");
            //            Console.WriteLine("Enter Account Number");
            //            int acnumber = System.Convert.ToInt32(Console.ReadLine());
            //            ourBank.DeleteAccount(acnumber);
            //            Console.WriteLine("---------------------------------------");
            //            ourBank.PrintAllAccounts();


            //        }
            //        else                                     // Transaction
            //        {


            //            Console.WriteLine("1. Withdraw ");
            //            Console.WriteLine("2. Deposit ");
            //            Console.WriteLine("3. Transfer ");
            //            Console.WriteLine("      ");
            //            Console.WriteLine(" Which Type Of Transaction do you want: ");
            //            int tra = System.Convert.ToInt32(Console.ReadLine());


            //            if (tra == 1)                           // Withdraw
            //            {
            //                //Console.WriteLine("Account Number: ");
            //                //int acnumber = System.Convert.ToInt32(Console.ReadLine());
            //                //Console.WriteLine("amount : ");
            //                //double taka = System.Convert.ToDouble(Console.ReadLine());
            //                //ourBank.Transaction(acnumber, taka);
            //                //Console.WriteLine("---------------------------------------");
            //                //ourBank.PrintAllAccounts();
            //            }


            //            else if (tra == 2)                       //Deposit
            //            {
            //                //Console.WriteLine("      ");
            //                //Console.WriteLine("Please give your Account number:");
            //                //int acnumber = System.Convert.ToInt32(Console.ReadLine());
            //                //Console.WriteLine("Please give your deposite amount:");
            //                //double taka = System.Convert.ToDouble(Console.ReadLine());
            //                //ourBank.Transaction2(acnumber, taka);
            //                //Console.WriteLine("---------------------------------------");
            //                //ourBank.PrintAllAccounts();
            //            }



            //            else                                     //Transfer
            //            {
            //                //Console.WriteLine("From: ");
            //                //Console.WriteLine("Please give sender Account number:");
            //                //int acnumber = System.Convert.ToInt32(Console.ReadLine());
            //                //Console.WriteLine("Please give the amount:");
            //                //double taka = System.Convert.ToDouble(Console.ReadLine());
            //                //ourBank.Transaction(acnumber, taka);

            //                //Console.WriteLine("To: ");
            //                //Console.WriteLine("Please give receiver Account number:");
            //                //int acnumber2 = System.Convert.ToInt32(Console.ReadLine());
            //                //ourBank.Transaction2(acnumber2, taka);
            //                //Console.WriteLine("transferred");
            //                //Console.WriteLine("---------------------------------------");
            //                //ourBank.PrintAllAccounts();
            //            }


        }
    }
        
    

