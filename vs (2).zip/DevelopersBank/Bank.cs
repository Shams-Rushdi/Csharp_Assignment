﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Bank
{

    public string bank_name { get; set; }
    Account[] Account = new Account[100];
    public static int aa = -1;
    public static int tt = 0;



    public Bank()
    {

    }
    public Bank(string name)
    {
        bank_name = name;




    }

    public void add_account(Account account)
    {
        //Console.WriteLine("\n Enter index number ( 0 - 99 )  in which you want to add this account,account name  {0} : \n",account.account_name);

        //int aa =Convert.ToInt32(Console.ReadLine());
        if (aa < Account.Length)
        {
            aa = aa + 1;
            Account[aa] = new Account();


            Account[aa].account_number = account.account_number;
            Account[aa].account_name = account.account_name;
            Account[aa].date_of_birth = account.date_of_birth;
            Account[aa].account_balance = account.account_balance;
            Account[aa].account_address = account.account_address;
            Account[aa].account_type = account.account_type;




        }
        else
        {
            Console.WriteLine("\n sorry can not open a account because of the storage limitation !! \n ");
        }


    }

    public Account search_person(string name, string date_of_birth1)
    {
        Account customer0 = new Account();
        try
        {
            for (int j = 0; j < Account.Length; j++)
            {
                try
                {
                    if (Account[j].account_name == name && Account[j].date_of_birth == date_of_birth1)
                    {

                        customer0 = Account[j];

                    }
                }
                catch (Exception)
                {

                }
            }


        }
        catch (Exception)
        {

        }
        return customer0;

    }








    public void delete_account(int account_no)
    {


        Console.WriteLine("\n after deleting account_no->## {0} ", account_no);
        for (int j = 0; j < Account.Length; j++)
        {
            try
            {
                if (Account[j].account_number == account_no)
                {
                    // Console.WriteLine("name ->#># {0} ",book[j].name );
                    Account[j] = new Account();

                }
            }
            catch (Exception)
            {
                //Console.WriteLine("no books in this place of the library");
            }
        }





    }


    public void Print_account_details()
    {
        Console.WriteLine("showing all the Account of this {0} bank : \n", this.bank_name);
        for (int i = 0; i < Account.Length; i++)
        {
            try
            {
                if (Account[i].account_balance >= 0)
                {
                    Console.WriteLine($"..............account place no : {i}  ................");
                    Console.WriteLine(" account_number: {0}", this.Account[i].account_number);
                    Console.WriteLine(" account_name: {0}", Account[i].account_name);
                    Console.WriteLine(" account_balance: {0}", Account[i].account_balance);
                    Console.WriteLine(" date of birth : {0}", Account[i].date_of_birth);
                    Console.WriteLine(" account_address: {0}", Account[i].account_address.get_address());

                }
            }
            catch (Exception)
            {
                //Console.WriteLine("no books in this place of the library");
            }

        }

    }





    public void show_account_balance_tranziton_times(Account itself)
    {
        try
        {
            Console.WriteLine("\n showing this accounts information  of {0} : \n", this.bank_name);
            for (int i = 0; i < Account.Length; i++)
            {
                if (Account[i].account_number == itself.account_number)
                {
                    try
                    {
                        if (Account[i].account_balance >= 0)
                        {
                            Console.WriteLine($"..............account place no : {i}  ................");
                            Console.WriteLine(" account_number: {0}", this.Account[i].account_number);

                            Console.WriteLine(" account_balance: {0}", Account[i].account_balance);
                            Console.WriteLine(" this account has successfully transfered money  : {0} times ", tt);


                        }
                    }
                    catch (Exception)
                    {
                        //Console.WriteLine("no books in this place of the library");
                    }
                }

            }
        }
        catch (Exception)
        {

        }


    }






    public void Transaction(int transaction_type, Account itself)
    {





        if (transaction_type == 1)
        {

            Console.WriteLine("\n Enter the ammount  that  you({0}) want  to transfer   : \n", itself.account_name);
            double amount = double.Parse(Console.ReadLine());




            Console.WriteLine("\n Enter the account number  where you want  to transfer  {0 } taka   : \n", amount);
            int transfered_account_no = Convert.ToInt32(Console.ReadLine());



            for (int j = 0; j < Account.Length; j++)
            {
                try
                {
                    if (Account[j].account_number == itself.account_number && Account[j].account_name == itself.account_name)
                    {

                        //Account[j] = new Account();
                        Account[j].account_balance = itself.withdraw(amount);

                    }
                    if (Account[j].account_number == transfered_account_no)
                    {

                        //Account[j] = new Account();
                        Account[j].account_balance = Account[j].deposite(amount);
                        tt = tt + 1;

                    }
                }
                catch (Exception)
                {
                    //Console.WriteLine("no books in this place of the library");
                }
            }



        }






        if (transaction_type == 2)
        {
            Console.WriteLine("\n Enter the amount that will be deposited to account_name  {0} : \n", itself.account_name);


            double amount = double.Parse(Console.ReadLine());
            //itself.deposite(amount);
            for (int j = 0; j < Account.Length; j++)
            {
                try
                {
                    if (Account[j].account_number == itself.account_number && Account[j].account_name == itself.account_name)
                    {

                        //Account[j] = new Account();
                        Account[j].account_balance = itself.deposite(amount);
                        break;

                    }
                }
                catch (Exception)
                {
                    //Console.WriteLine("no books in this place of the library");
                }
            }


        }





        if (transaction_type == 3)
        {
            Console.WriteLine("\n Enter the amount that will be withdrawn  from account_name  {0} : \n", itself.account_name);


            // double amount = double.Parse(Console.ReadLine());
            //itself.withdraw(amount);
            double amount = double.Parse(Console.ReadLine());
            //itself.deposite(amount);
            for (int j = 0; j < Account.Length; j++)
            {
                try
                {
                    if (Account[j].account_number == itself.account_number && Account[j].account_name == itself.account_name)
                    {

                        //Account[j] = new Account();
                        if (Account[j].account_balance - amount > 0 && Account[j].account_type == "saving")
                        {
                            Account[j].account_balance = itself.withdraw(amount);
                        }
                        else
                        {
                            Console.WriteLine("can't  withdraw an ammount that will make the saving account balance < 0");
                        }
                        if (Account[j].account_balance - amount >= 0 && Account[j].account_type == "checking")
                        {
                            Account[j].account_balance = itself.withdraw(amount);
                        }


                    }
                }
                catch (Exception)
                {
                    //Console.WriteLine("no books in this place of the library");
                }
            }


        }


    }







}