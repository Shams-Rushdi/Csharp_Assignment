﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Account
{


    public int account_number;
    public string account_name { get; set; }
    public string date_of_birth { get; set; }
    public double account_balance { get; set; }
    public string account_type { get; set; }
    public static double balance_counter = 0;
    public Address account_address;


    public Account()
    {

    }

    //  public Account(string a_name,double balance,Address address)
    //   {
    //     Random r = new Random();
    //       int n = r.Next();

    //      account_number = n;
    //      account_name = a_name;
    //      account_balance = balance;
    //      account_address = address;



    //   }


    public Account(string a_name, string date, double balance, Address address, string type)
    {
        Random r = new Random();
        int n = r.Next();

        account_number = n;
        account_name = a_name;
        date_of_birth = date;
        account_balance = balance;
        account_address = address;
        account_type = type;



    }


    public double withdraw(double amount)
    {
        this.account_balance = this.account_balance - amount;

        return account_balance;

    }


    public double deposite(double amount)
    {
        account_balance = account_balance + amount;

        return account_balance;
    }
    public void transfer(Account reciver, double amount)
    {
        reciver.account_balance = reciver.account_balance + amount;
        account_balance = account_balance - amount;



    }

    public void show_account_information()
    {

        Console.WriteLine("account_no :{0}", this.account_number);
        Console.WriteLine("account_name :{0}", this.account_name);
        Console.WriteLine("account_balance :{0}", this.account_balance);
        Console.WriteLine("account_address :{0}", this.account_address.get_address());




    }






}
