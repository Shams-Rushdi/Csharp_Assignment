﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public static class Bank_main
{
    public static int Main(string[] args)
    {

        //         Address d = new Address("12","2/56a","Dinajpur","Bangladesh");  
        //         Address d1 = new Address("12","2/56a","Dinajpur","england");  
        //          Console.WriteLine(" {0} ",d.get_address());
        //         //     string aaa;
        //         //  Console.WriteLine("\n give a name :\n");
        //         //  aaa=Console.ReadLine();

        //          Account a1 = new Account("muna ","1/10/2001",14000.00,d);
        //          a1.show_account_information();
        //          Account a = new Account("uddipta","1/10/2001",500.00,d1);
        //          Account a2 = new Account("juli","1/10/2001",5400.00,d1);

        // //string a_name,double balance,Address address
        // Bank b= new Bank("devoloper Bank ");
        // b.add_account(a);
        // b.add_account(a1);
        // b.add_account(a2);
        // b.Print_account_details();
        // Console.WriteLine("\n  give the account_no which should be deleted : \n");
        // int account_num =Convert.ToInt32(Console.ReadLine());
        // b.delete_account(account_num);
        // b.Print_account_details();
        // b.Transaction(1,a1);
        // b.Transaction(2,a1);
        // b.Print_account_details();
        // b.Transaction(3,a1);
        // b.Print_account_details();
        // b.show_account_balance_tranziton_times(a);
        // b.Transaction(1,a1);
        // b.show_account_balance_tranziton_times(a);
        // b.show_account_balance_tranziton_times(a2);


        Bank b = new Bank("devoloper Bank ");
        string choice;
        int g = 0;

        while (g != 1)
        {
            Console.WriteLine("\n Give an input open/account/quit \n");
            choice = Console.ReadLine();

            switch (choice)
            {
                case "open":

                    while (g != 2)
                    {
                        Console.WriteLine("    Give an input saving/checking/quit \n");
                        string choice1 = Console.ReadLine();


                        switch (choice1)
                        {
                            case "saving":
                                Console.WriteLine("name : \n");
                                string v1 = Console.ReadLine();
                                Console.WriteLine("date of birth : \n");
                                string v2 = Console.ReadLine();
                                Console.WriteLine("country : \n");
                                string v3 = Console.ReadLine();
                                Console.WriteLine("district : \n");
                                string v4 = Console.ReadLine();
                                Console.WriteLine("road no : \n");
                                string v5 = Console.ReadLine();
                                Console.WriteLine("house no  : \n");
                                string v6 = Console.ReadLine();

                                Console.WriteLine("ammount : \n");
                                double v7 = double.Parse(Console.ReadLine());

                                //         Address d = new Address("12","2/56a","Dinajpur","Bangladesh");  
                                //          Account a2 = new Account("juli","1/10/2001",5400.00,d1);
                                Address d1 = new Address(v6, v5, v4, v3);
                                Account a1 = new Account(v1, v2, v7, d1, "saving");
                                b.add_account(a1);
                                //b.Print_account_details();
                                Console.WriteLine("  successfully account created !! \n");

                                break;
                            case "checking":
                                Console.WriteLine("name : \n");
                                string v11 = Console.ReadLine();
                                Console.WriteLine("date of birth : \n");
                                string v22 = Console.ReadLine();
                                Console.WriteLine("country : \n");
                                string v33 = Console.ReadLine();
                                Console.WriteLine("district : \n");
                                string v44 = Console.ReadLine();
                                Console.WriteLine("road no : \n");
                                string v55 = Console.ReadLine();
                                Console.WriteLine("house no  : \n");
                                string v66 = Console.ReadLine();

                                Console.WriteLine("ammount   : \n");
                                double v77 = double.Parse(Console.ReadLine());

                                //         Address d = new Address("12","2/56a","Dinajpur","Bangladesh");  
                                //          Account a2 = new Account("juli","1/10/2001",5400.00,d1);
                                Address d11 = new Address(v66, v55, v44, v33);
                                Account a11 = new Account(v11, v22, v77, d11, "checking");
                                b.add_account(a11);
                                //b.Print_account_details();

                                Console.WriteLine("  successfully account created !! \n");

                                break;
                            case "quit":
                                g = 2;
                                break;
                            default:
                                Console.WriteLine("some thing went wrong ......");
                                break;

                        }

                    }


                    break;

                case "account":
                    while (g != 3)
                    {
                        Console.WriteLine("    Give an input deposite/withdraw/transfer/show/quit \n");
                        string choice2 = Console.ReadLine();
                        switch (choice2)
                        {
                            case "deposite":
                                Console.WriteLine(" give your name : ");
                                string name1 = Console.ReadLine();
                                Console.WriteLine(" give your date of birth : ");
                                string date_of_birth1 = Console.ReadLine();
                                Account customer1 = b.search_person(name1, date_of_birth1);
                                b.Transaction(2, customer1);

                                break;

                            case "withdraw":
                                Console.WriteLine(" give your name : ");
                                string name2 = Console.ReadLine();
                                Console.WriteLine(" give your date of birth : ");
                                string date_of_birth2 = Console.ReadLine();
                                Account customer2 = b.search_person(name2, date_of_birth2);
                                b.Transaction(3, customer2);
                                break;
                            case "transfer":
                                Console.WriteLine(" give your name : ");
                                string name3 = Console.ReadLine();
                                Console.WriteLine(" give your date of birth : ");
                                string date_of_birth3 = Console.ReadLine();
                                Account customer3 = b.search_person(name3, date_of_birth3);
                                b.Transaction(1, customer3);
                                break;
                            case "show":

                                Console.WriteLine(" give your name : ");
                                string name4 = Console.ReadLine();
                                Console.WriteLine(" give your date of birth : ");
                                string date_of_birth4 = Console.ReadLine();
                                Account customer4 = b.search_person(name4, date_of_birth4);
                                b.show_account_balance_tranziton_times(customer4);



                                break;
                            case "quit":
                                g = 3;
                                break;
                            default:
                                Console.WriteLine("some thing went wrong ......");
                                break;

                        }
                    }
                    break;

                case "quit":
                    g = 1;
                    break;

                default:
                    Console.WriteLine("some thing went wrong ......");
                    break;
            }




        }



        //b.Print_account_details();



        return 0;
    }
}