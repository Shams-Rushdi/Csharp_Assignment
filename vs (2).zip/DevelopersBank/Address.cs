﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Address
{

    public string rood_no { get; set; }
    public string house_no { get; set; }
    public string city_name { get; set; }
    public string country_name { get; set; }

    public Address()
    {

    }





    public Address(string road, string house, string city, string country)
    {
        rood_no = road;
        house_no = house;
        city_name = city;
        country_name = country;

    }


    //  public Address(string nam,string date,string road,string house,string city,string country)
    //   {
    //       name = nam;
    //       date_of_birth = date
    //       rood_no = road;
    //      house_no = house;
    //      city_name=city;
    //     country_name = country;

    //   }




    public string get_address()
    {
        string a = "";

        a = " " + rood_no + ", " + house_no + " ," + city_name + " ," + country_name;
        return a;
    }



}